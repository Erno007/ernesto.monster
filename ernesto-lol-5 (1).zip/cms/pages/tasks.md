---
title: tasks
permalink: '{{ page.fileSlug }}/index.html'
layout: tasks.html
slug: tasks
tags: pages
---


