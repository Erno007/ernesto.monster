---
f_email: h_mortelmans@icloud.com
f_adres: |-
  Rue Plantin 25,
  1070 Anderlecht
  Brussel, België
title: Hans Mortelmans
slug: hans-mortelmans
updated-on: '2023-04-24T16:53:21.563Z'
created-on: '2023-04-24T15:38:10.020Z'
published-on: '2023-04-24T17:23:52.158Z'
f_points-available: 21
layout: '[hans-mortelmans].html'
tags: hans-mortelmans
---


